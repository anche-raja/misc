# FORGE — Phase 1: Discovery + Risk Scorer
# Build on top of the Phase 0 MVP

## Prerequisite
Phase 0 MVP is complete and working. You have a running FORGE pipeline that processes Java files through guardrails, transforms, review, and writes to DynamoDB. This phase adds intelligence before any transformation runs.

## Goal
Before touching a single Java file, FORGE should know everything about the codebase. This phase adds two agents that run as Phase 0 of every migration — they produce the migration manifest that all future transform agents depend on. Discovery costs zero Bedrock tokens. Risk Scorer costs minimal tokens. Together they answer: what is here, what depends on what, what should we do first, and what should go straight to human review.

## What "done" looks like for this phase

  python migrate.py ./myapp --phase discover

Produces migration-manifest.json in the source directory containing:
- Complete file inventory with type classification for every file
- Dependency graph (which action classes extend which base classes, which forms belong to which actions, which JSPs link to which actions)
- Risk score and tier for every Java file
- Recommended processing order (topological sort — base classes before derived classes)
- Files pre-flagged for manual review (score > 90 or any OGNL projection detected)
- Estimated Bedrock cost if a full migration were run

Also update the Phase 0 CLI so that --phase java21 reads this manifest and processes files in the recommended order, skipping files already flagged for manual review.

## What NOT to build in this phase
No LLM-based file transformation. No review agents beyond what already exists. No struts.xml parsing (that comes in Phase 3). No Spring or Struts-specific logic.

## New files to add (everything else from Phase 0 stays unchanged)

forge/
  agents/
    discovery.py          ← new
    risk_scorer.py        ← new
  manifest/
    __init__.py           ← new
    migration_manifest.py ← new
  utils/
    dependency_graph.py   ← new
tests/
  test_discovery.py       ← new
  test_risk_scorer.py     ← new

## Discovery Agent — forge/agents/discovery.py
This agent does NOT call Bedrock. It is pure Python filesystem analysis. No LLM, no cost.

Walk the source_dir recursively. For each file classify it:

Java files — read the first 50 lines (imports and class declaration). Classify as:
  action_class: imports or extends ActionSupport, Action, DispatchAction
  form_bean: imports or extends ActionForm, DynaActionForm, ModelDriven
  base_class: abstract class that other action classes extend
  interceptor: implements Interceptor or extends AbstractInterceptor
  service: annotated with @Service or @Component (not a controller)
  controller: annotated with @Controller (already migrated — skip)
  test: path contains src/test
  config: filename is applicationContext.xml, web.xml, struts.xml
  utility: none of the above

XML files — classify as:
  struts_config: filename is struts.xml or struts-config.xml
  spring_config: filename is applicationContext.xml or beans.xml
  web_config: filename is web.xml
  other_xml

JSP files — scan for <s:> tags. Classify as:
  struts_view: contains <s: tags
  spring_view: contains <form: tags (already migrated)
  plain_jsp: neither

Properties files — classify as:
  struts_properties: filename is struts.properties
  application_properties: filename is application.properties or application.yml
  other_properties

Build the dependency graph. For each action_class Java file:
  Read extends clause → base_class dependency
  Read implements clause → if ModelDriven<T> or Preparable, record T as linked form_bean
  Read @Result annotations → linked JSP file paths
  Read interceptorRef in struts.xml if present → linked interceptors

Detect Struts version:
  If any file imports com.opensymphony.xwork2.* → Struts 2.x
  If any file imports org.apache.struts.action.* → Struts 1.x (flag — out of scope, warn)

Build topological processing order:
  base_class files first
  form_bean files second
  interceptor files third
  action_class files fourth (bundle with their linked JSPs)
  standalone JSP files last

Output: save migration-manifest.json to source_dir root.

## Migration Manifest — forge/manifest/migration_manifest.py
A dataclass or Pydantic model that holds:
  total_files: int
  by_type: dict (type → count)
  struts_version: str
  dependency_graph: dict (file_path → list of dependency file_paths)
  processing_order: list of file_paths in correct order
  file_metadata: dict (file_path → {type, loc, package, class_name})
  risk_scores: dict (file_path → {score, tier, signals})
  manual_bypasses: list of file_paths (pre-flagged before scoring)

Methods:
  save(path): write to JSON
  load(path): read from JSON
  get_files_for_phase(phase, status_manager): return files in processing order, filtered by DynamoDB status (skip DONE files on --resume)
  get_risk_tier(file_path): return LOW/MEDIUM/HIGH/UNSCORED
  get_risk_score(file_path): return int 0-100

## Risk Scorer Agent — forge/agents/risk_scorer.py
This agent calls Bedrock but only once per file for analysis, not transformation. Uses Claude Sonnet 4.5.

For each Java file classified as action_class or form_bean, score it 0-100:

  LOC score (0-20):
    < 200 lines: 0
    200-500 lines: 5
    500-1000 lines: 10
    > 1000 lines: 20

  OGNL score (0-30) — count %{} expressions in linked JSP files:
    0 expressions: 0
    1-5 expressions: 10
    6-15 expressions: 20
    > 15 OR any projection (%{list.{field}}) OR selection (%{list.{? cond}}) OR static method (%{@Class@method()}): 30

  Interceptor score (0-20):
    No interceptors: 0
    Standard stack only: 5
    Custom interceptor reference: 15
    Custom interceptor that calls invocation.getAction(): 20

  EJB score (0-20):
    No EJB: 0
    @EJB annotations: 10
    JNDI lookups in action code: 15
    EJB home interface calls: 20

  Pattern score (0-10):
    ModelDriven alone: 3
    Preparable alone: 3
    ModelDriven + Preparable combined: 8
    Custom result type: 10

Total = sum of all scores.
Tier: LOW 0-30, MEDIUM 31-60, HIGH 61-100.

Files scoring > 90 OR files with any OGNL projection/selection/static method detected → add to manual_bypasses in manifest. These skip transform entirely and go straight to manual-review-queue.json when the relevant phase runs.

The risk scorer does NOT need to call Bedrock for simple counting. Use Python to count LOC, count OGNL expressions with regex, detect EJB with import scanning. Only call Bedrock if you need to detect complex patterns the regex misses (e.g. whether a custom interceptor accesses ActionInvocation).

## Update the CLI — migrate.py changes
Add --phase discover as a valid phase choice.

When --phase discover runs: run Discovery agent (no Bedrock), run Risk Scorer (minimal Bedrock), save manifest, print summary, generate report. Do NOT run the LangGraph pipeline for discover phase — it is pure analysis.

When --phase java21 runs: load manifest if it exists. Process files in manifest.processing_order order. Skip files in manual_bypasses (log them as pre-flagged). If manifest does not exist: run discovery first automatically, then transform.

## Update DynamoDB — add manifest storage
Add a second DynamoDB table: forge-migration-manifest. Stores the manifest as a single JSON item with primary key = source_dir. This allows multiple engineers to query manifest data without reading the JSON file directly.

## Report updates
Add to migration-report.md:
  Discovery section: file type breakdown, Struts version detected, dependency graph summary, processing order.
  Risk section: LOW/MEDIUM/HIGH/BYPASS counts, top 10 highest-risk files.
  Estimated cost section: projected Bedrock cost if full pipeline were run.

## Tests
test_discovery.py: given a directory with sample Java files, assert correct classification, correct dependency detection, correct processing order.
test_risk_scorer.py: given a file with known properties (200 LOC, 3 OGNL expressions, no EJB), assert correct score.

## Acceptance criteria — phase 1 is complete when
1. python migrate.py ./myapp --phase discover runs in under 2 minutes with no Bedrock calls for pure classification.
2. migration-manifest.json exists and contains correct file types for all files in the codebase.
3. Running --phase java21 after --phase discover processes files in topological order (base classes before derived classes).
4. Files pre-flagged by risk scorer (score > 90) appear in migration-report.md as BYPASS, not in DynamoDB as PENDING.
5. Both new tests pass.
