# FORGE — Phase 2: Spring Upgrade Agent + LiteLLM
# Build on top of Phases 0 and 1

## Prerequisite
Phases 0 and 1 are complete. FORGE can scan a codebase, score files, process them in dependency order, run the Java upgrade through guardrails and review, write results to DynamoDB, and trace everything in LangSmith.

## Goal
Two deliverables in this phase. First: add the Spring 5→6 transform agent so FORGE can handle the second major upgrade after Java. Second: introduce LiteLLM as the provider abstraction layer so switching from Bedrock to an internal LLM in the future requires only a config file change, not a code change.

## What "done" looks like for this phase

  python migrate.py ./myapp --phase spring6

Runs every Java file through the Spring 5→6 agent. WebSecurityConfigurerAdapter is removed and replaced with SecurityFilterChain @Bean. antMatchers replaced with requestMatchers. Jackson patterns updated. pom.xml Spring Boot version bumped. Nova Pro reviews and scores.

  LITELLM_PROXY=true python migrate.py ./myapp --phase java21

Routes all LLM calls through the LiteLLM proxy instead of directly to Bedrock. The agent code is unchanged — only the model client is swapped.

## New files to add

forge/
  agents/
    spring_upgrade.py     ← new
  review/
    spring_reviewer.py    ← new
  llm/
    __init__.py           ← new
    client.py             ← new (replaces direct ChatBedrockConverse in base.py)
litellm-config.yaml       ← new
tests/
  test_spring_upgrade.py  ← new
  test_llm_client.py      ← new

## LiteLLM abstraction — forge/llm/client.py
Create a build_llm_client(model_name, config) factory function. If config.use_litellm_proxy is True: return ChatOpenAI with base_url=config.litellm_endpoint, api_key=config.litellm_api_key, model=model_name. If False: return ChatBedrockConverse with model=model_name, region_name=config.aws_region.

Update forge/agents/base.py to call build_llm_client() instead of constructing ChatBedrockConverse directly. This is the only change to base.py — everything else stays identical. All existing agents get LiteLLM support automatically through this one change.

## litellm-config.yaml
Route claude-sonnet-4-5 to Bedrock today. Route amazon.nova-pro-v1 to Bedrock today. Include commented-out entries showing how to route to an internal LLM endpoint in the future. Include litellm_settings: drop_params=true, num_retries=3, request_timeout=120.

## Update agents.yaml
Add: use_litellm_proxy (bool, default false), litellm_endpoint (URL), litellm_api_key (env var reference).

## Spring Upgrade Agent — forge/agents/spring_upgrade.py
System prompt instructs Claude Sonnet 4.5 to apply these rules:

Rule 1 — WebSecurityConfigurerAdapter removal: detect any class extending WebSecurityConfigurerAdapter. Extract the configure(HttpSecurity http) method body. Rewrite as a @Bean SecurityFilterChain(HttpSecurity http) method returning http.build(). Move configure(AuthenticationManagerBuilder) content to a @Bean AuthenticationManager method. Remove the extends clause. This is the highest-priority rule — Spring 6 will not compile if this class is present.

Rule 2 — antMatchers to requestMatchers: find every .antMatchers() call, replace with .requestMatchers(). Find .mvcMatchers(), replace with .requestMatchers(). Find .regexMatchers(), replace with .requestMatchers(RegexRequestMatcher). Applies inside any method in any file — not just security config classes.

Rule 3 — Jackson serialisation updates: find ObjectMapper.configure(MapperFeature.DEFAULT_VIEW_INCLUSION, ...) → update to builder API. Check @JsonIgnoreProperties placement. Update DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES patterns if present.

Rule 4 — pom.xml version bump: detect current spring-boot-starter-parent version. If it is a Spring Boot 2.x version, bump to the Spring Boot 3.x version specified in agents.yaml (target_spring_boot_version). Add hibernate-validator dependency if spring-boot-starter-validation is present but hibernate-validator is not explicit.

Rule 5 — Property migration: remove spring.mvc.pathmatch.use-suffix-pattern from application.properties if present. Update server.error.include-stacktrace: always → on_param if present.

Return JSON with: files dict (path→content), manual_flags list (file+line+reason). Flag for manual review: custom OAuth2 configuration, custom AuthProvider beans, method security annotations (@PreAuthorize with complex SpEL).

The agent receives review feedback in the prompt when retry_count > 0 — same pattern as java_upgrade.py.

## Spring Reviewer — forge/review/spring_reviewer.py
Uses Nova Pro. Check and score 0-100:

Check 1 (25pts): WebSecurityConfigurerAdapter completely absent. SecurityFilterChain @Bean present and correctly structured.
Check 2 (25pts): Zero antMatchers() or mvcMatchers() calls. All replaced with requestMatchers().
Check 3 (20pts): Jackson patterns are Spring 6 compliant. No deprecated MapperFeature usage.
Check 4 (20pts): pom.xml Spring Boot version is 3.x. hibernate-validator present if validation is used.
Check 5 (10pts): application.properties does not contain deprecated Spring Boot 2 properties.

PASS >= 80. RETRY 50-79. MANUAL < 50.

## Update LangGraph graph — forge/graph.py
Add spring_upgrade and spring_reviewer nodes. Add routing: after spring_upgrade → spring_reviewer. After spring_reviewer: same PASS/RETRY/MANUAL logic as java_reviewer. The select_transform_agent and select_review_agent functions already route by phase — just add the spring6 entries.

## Update CLI — migrate.py
Add spring6 to valid --phase choices. No other CLI changes needed.

## Update agents.yaml
Add: target_spring_boot_version (e.g. "3.2.0"), source_spring_version ("5"), target_spring_version ("6").

## Multi-phase run
When --phase all is specified (or when called from a future orchestrator), phases run in this order: discover → java21 → spring6. Each phase reads the manifest from Phase 1 and processes files in dependency order. A file must complete java21 phase with status DONE before it enters spring6 phase — enforce this by checking DynamoDB status.

## Tests
test_spring_upgrade.py: given a Java file with WebSecurityConfigurerAdapter, assert the agent prompt includes Rule 1 instructions and the output contains SecurityFilterChain.
test_llm_client.py: assert that build_llm_client returns ChatOpenAI when use_litellm_proxy=True and ChatBedrockConverse when False. Mock both to avoid real API calls.

## Acceptance criteria — phase 2 is complete when
1. python migrate.py ./myapp --phase spring6 runs a file containing WebSecurityConfigurerAdapter through the full pipeline and writes a corrected file to ./migrated/.
2. LITELLM_PROXY=true python migrate.py ./myapp --phase java21 --file any_file.java routes the LLM call through LiteLLM without any code change in the agent.
3. DynamoDB shows separate records for java21 and spring6 phases for the same file.
4. LangSmith shows spring_upgrade and spring_reviewer as separate trace nodes.
5. Both new tests pass.
