# FORGE — Phase 3: Struts2 → Spring MVC Elimination
# Build on top of Phases 0, 1, and 2
# This is the core mission of FORGE

## Prerequisite
Phases 0, 1, and 2 are complete. FORGE processes Java files through Java upgrade and Spring upgrade with full pipeline, guardrails, review, DynamoDB, LangSmith, and LiteLLM. The manifest knows the dependency graph and processing order.

## Goal
The Struts2→MVC agent eliminates every Struts 2 construct from the codebase. After this phase runs: zero ActionSupport classes, zero OGNL expressions, zero struts.xml routing, zero <s:> JSP tags. This is the highest-complexity agent in FORGE. It requires cross-file context — it cannot transform a file in isolation because it needs the routing map from struts.xml, the already-transformed base class, and the linked JSPs. This phase introduces the context builder and the struts.xml parser.

## What "done" looks like for this phase

  python migrate.py ./myapp --phase struts

Before starting, shows: "HUMAN GATE: About to run struts phase. Review migration-report.md first. Proceed? (yes/no):" — waits for engineer confirmation.

After confirmation: processes every action class, form bean, interceptor, JSP file in dependency order (base classes → forms → interceptors → actions bundled with JSPs → standalone JSPs → WebMvcConfigurer). Writes @Controller classes, @ModelAttribute DTOs, updated JSPs, HandlerInterceptor stubs to ./migrated/. Files with OGNL projections/selections/static methods go to manual-review-queue.json with the specific OGNL pattern identified.

  grep -r "ActionSupport\|extends Action\|%{" ./migrated/

Returns zero results.

## New files to add

forge/
  agents/
    struts2_mvc.py        ← new
  review/
    struts_reviewer.py    ← new
  utils/
    struts_xml_parser.py  ← new
    context_builder.py    ← new
  queue/
    __init__.py           ← new
    manual_queue.py       ← new (writes to manual-review-queue.json, SQS in Phase 5)
tests/
  test_struts2_mvc.py     ← new
  test_context_builder.py ← new
  test_struts_xml_parser.py ← new

## struts.xml Parser — forge/utils/struts_xml_parser.py
Parse struts.xml (or struts-config.xml) ONCE before any Java file is transformed. This is a pure Python XML parser — no LLM, no Bedrock.

Extract for each action mapping:
  namespace (e.g. /user)
  action name (e.g. list)
  class name (e.g. com.corp.UserAction)
  method name (e.g. list, or execute if not specified)
  results: each result has a name (success, input, error) and type (dispatcher, redirectAction, chain) and location (JSP path or action name)
  interceptor stack reference (default, validationStack, etc.)

Build a routing_map dict: keyed by fully-qualified class name. Value: list of action entries (namespace, action_name, method, results, interceptors).

Also parse interceptor definitions: for each <interceptor> element extract name and class. For each <interceptor-stack> extract the stack members in order.

Store routing_map in the manifest under a new routing_map key. This map is loaded by the context builder for every file transformation.

## Context Builder — forge/utils/context_builder.py
Before the Struts2MvcAgent receives a file, the context builder assembles everything it needs to understand that file. This is what makes per-file transformation work despite cross-file dependencies.

Given a file_path and the manifest, build a context bundle:

  routing_context: look up file_path's class name in routing_map. Return the full routing entry (namespace, actions, results, interceptors). If not found: empty dict.

  base_class_context: look up file_path's base class in dependency_graph. If the base class has already been transformed (DynamoDB status=DONE): read the transformed file from ./migrated/. If not yet transformed: read the original source. Include whichever is available.

  form_bean_context: look up linked form_bean in dependency_graph. Same logic — prefer transformed version from ./migrated/ if DONE.

  linked_jsps: look up @Result locations in routing_map. For each JSP path: read the JSP content. Bundle together with the action file when the JSP contains OGNL model expressions (tight coupling).

  interceptor_context: look up interceptor class references. For each custom interceptor (not standard stack): read the interceptor source file.

Return a context_bundle dict. Add this to ForgeState before the transform node runs. The context_builder runs as a function called by the Leader routing logic before dispatching to struts2_mvc.

## Struts2→MVC Agent — forge/agents/struts2_mvc.py
This is the most complex agent. System prompt must cover five rules precisely.

Rule 1 — Class conversion: remove extends ActionSupport or Action. Remove implements ModelDriven<T> and implements Preparable. Add @Controller. Add @RequestMapping("{namespace}") — get namespace from routing_context in the prompt. If ModelDriven<T>: add @ModelAttribute method returning new T(). If Preparable: merge prepare() and prepareXxx() logic into the @ModelAttribute method.

Rule 2 — Method conversion: for each action entry in routing_context, create a method named after the action name. Determine HTTP method: GET if the action reads/displays, POST if it saves/updates/deletes (use method name as signal — list/view/show → GET, save/create/update/delete/submit → POST). Map result names: SUCCESS with dispatcher → return "namespace/viewname". SUCCESS with redirectAction → return "redirect:/target/action". INPUT result → add BindingResult parameter and if (bindingResult.hasErrors()) return "viewname".

Rule 3 — Field extraction to DTO: collect all fields that have both getter and setter — these are OGNL-bound. Create a new XxxForm.java class with those fields as a @ModelAttribute class. Analyse the validate() method: null/empty checks → @NotBlank. length checks → @Size. numeric range → @Min/@Max. email pattern → @Email. If validate() calls any service or DAO method: keep the validation logic as a separate Spring Validator class and flag MANUAL.

Rule 4 — JSP tag replacement: process each linked JSP included in the context bundle. Replace <s:form action="x"> with <form:form modelAttribute="xForm" action="x">. Replace <s:textfield name="f"> with <form:input path="f"/>. Replace <s:select> with <form:select>. Replace <s:textarea> with <form:textarea>. Replace <s:iterator value="%{list}"> with <c:forEach items="${list}" var="item">. Replace <s:if test="%{cond}"> with <c:if test="${cond}">. Replace <s:property value="%{x}"> with ${x}. Replace %{fieldName} with ${fieldName}. For OGNL projections %{list.{field}}, selections %{list.{? cond}}, and static methods %{@Class@method()}: do NOT replace. Add a comment FLAG_MANUAL: [pattern] and include in manual_flags. The taglib declaration at the top of each JSP must be updated to remove <%@ taglib prefix="s" uri="/struts-tags" %> and add the Spring form and JSTL taglibs.

Rule 5 — Interceptor mapping: if the routing_context shows only standard interceptor stacks (defaultStack, validationStack, paramsPrepareParamsStack) — document this in a comment but take no code action, they become irrelevant in Spring MVC. If a custom interceptor is referenced: generate a HandlerInterceptor stub class with preHandle, postHandle, afterCompletion methods and a comment showing where to add the logic. Add a WebMvcConfigurer entry registering this interceptor. If the interceptor source code (in interceptor_context) accesses invocation.getAction() or invocation.getStack(): flag MANUAL — cannot auto-convert.

Return JSON: files dict (path→content for each generated/modified file), manual_flags list (file, line, pattern, reason), webmvc_additions list (interceptor registrations for WebMvcConfigurer).

## Struts Reviewer — forge/review/struts_reviewer.py
Uses Nova Pro. Five checks:

Check 1 (20pts): Zero ActionSupport, Action, or Struts class references anywhere in the output files.
Check 2 (20pts): Every action in the routing_context has a corresponding @RequestMapping method in the generated @Controller. No routes missing.
Check 3 (25pts): Zero OGNL %{} expressions in any JSP file. Only ${} EL expressions present.
Check 4 (20pts): Zero <s:> tags in any JSP. All replaced with <form:>, <c:>, or JSTL equivalents.
Check 5 (15pts): Result mappings are correct — SUCCESS dispatcher becomes view name, SUCCESS redirectAction becomes redirect: prefix, INPUT becomes hasErrors() guard.

PASS >= 80. RETRY 50-79. MANUAL < 50.

## Manual Queue — forge/queue/manual_queue.py
For Phase 3, write MANUAL files to manual-review-queue.json. Each entry includes: file_path, reason (list of specific issues), original_source, best_transform_attempt (the LLM output even though it didn't pass), review_score, review_feedback, manual_flags (specific OGNL patterns or interceptor issues). Engineers open this file to see exactly what needs human attention and why.

## Human Gate — update migrate.py
Before the struts phase starts, print: "HUMAN GATE — About to run struts phase. This eliminates all Struts 2 constructs. Review migration-report.md before proceeding." Wait for user to type "yes". If anything else: exit with message "Aborted. Run --phase discover and --phase java21 and --phase spring6 first, review the report, then re-run."

## Update LangGraph graph — forge/graph.py
Add struts2_mvc and struts_reviewer nodes. Add context_builder_node that runs before struts2_mvc — it calls the context builder and adds the context_bundle to ForgeState. Routing after struts_reviewer: same PASS/RETRY/MANUAL logic.

Processing order enforcement: before queueing files for the struts phase, verify that each file's java21 and spring6 status in DynamoDB is DONE. Files where the prerequisite phases are not DONE should be skipped with a warning — they cannot safely enter Struts elimination until the Java and Spring layers are clean.

## Update agents.yaml
Add struts phase to human_gates list. No other changes needed.

## Tests
test_struts_xml_parser.py: given a sample struts.xml, assert correct namespace, action, method, result, and interceptor extraction.
test_context_builder.py: given a file with a known base class and linked JSP, assert the context bundle contains the base class source and the JSP content.
test_struts2_mvc.py: given the prompt built for a known file, assert it contains the routing_context section and the base_class_context section.

## Acceptance criteria — phase 3 is complete when
1. python migrate.py ./myapp --phase struts runs and the human gate prompt appears.
2. After confirming, files are processed in the correct dependency order (base classes before derived classes).
3. grep -r "ActionSupport\|extends Action" ./migrated/ returns zero results for processed files.
4. Files with OGNL projections appear in manual-review-queue.json with the specific pattern identified.
5. All three new tests pass.
6. The Struts reviewer correctly identifies and flags any residual Struts patterns with specific line references.
