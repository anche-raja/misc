# FORGE — Phase 4: OpenHands Compile Verification
# Build on top of Phases 0, 1, 2, and 3

## Prerequisite
Phases 0 through 3 are complete. FORGE eliminates Struts 2 from the codebase. Transform agents produce output that goes to Nova Pro review. Some retries are caused by compile errors — trivial import issues or missing annotations that Claude introduced and that Nova Pro caught. This phase eliminates that class of problem entirely.

## Goal
Every transform agent — java_upgrade, spring_upgrade, struts2_mvc — should produce compile-verified output before the review agent ever sees it. The developer never sees a Java compile error from FORGE output. The agent finds and fixes its own compile errors autonomously using OpenHands, running mvn compile in a Docker sandbox.

The developer experience improvement is: compile errors become invisible. They are auto-fixed and logged in the audit trail but never surface as RETRY or MANUAL escalations. Review scores go up. Retry rate drops.

## What "done" looks like for this phase

Normal FORGE run — output now shows compile verification:

  [1/247] UserAction.java
    → Transform (Claude Sonnet 4.5)
    → Compile verify (OpenHands)
        attempt 1: BUILD FAILURE — javax.servlet import not updated
        fixing... updated 3 imports
        attempt 2: BUILD SUCCESS
    → Review (Nova Pro) → score: 91 PASS
    → Written ✓ (1 Bedrock call, 0 retries)

vs the old output without compile verification:

  [1/247] UserAction.java
    → Transform (Claude Sonnet 4.5)
    → Review (Nova Pro) → score: 62 RETRY
    → Retry (Claude Sonnet 4.5)
    → Review (Nova Pro) → score: 88 PASS
    → Written ✓ (2 Bedrock calls, 1 retry)

## What NOT to build in this phase
No new transform agents. No new review agents. No changes to the LangGraph routing logic. No changes to DynamoDB schema. Only the compile verification layer is added.

## New files to add

forge/
  openhands/
    __init__.py           ← new
    sandbox.py            ← new
    compile_verifier.py   ← new
docker/
  forge-build-env/
    Dockerfile            ← new
    pom-warmup.xml        ← new
tests/
  test_compile_verifier.py ← new

## Pre-built Docker image — docker/forge-build-env/
Build a Docker image with JDK 21 and Maven 3.9 pre-installed. Pre-warm the Maven dependency cache by running mvn dependency:resolve against a pom-warmup.xml that includes spring-boot-starter-web, spring-boot-starter-security, spring-boot-starter-validation, spring-boot-starter-data-jpa, and spring-boot-starter-test. After cache warming, mvn compile inside the sandbox runs in seconds with no network calls.

Include instructions in the Dockerfile comments: "Build this image once before running FORGE: docker build -t forge-build-env:latest docker/forge-build-env/"

## OpenHands Compile Verifier — forge/openhands/compile_verifier.py
A class named OpenHandsCompileVerifier with one primary method: verify_and_fix(files, workspace_path, pom_path).

files: dict of path→content (the LLM-generated files).
workspace_path: the sandbox directory for this file (under /tmp/forge-sandbox/{hash of file_path}).
pom_path: path to the project pom.xml.

The method:
1. Creates the workspace directory.
2. Writes all files to the workspace.
3. Spins up an OpenHands agent with TerminalTool and FileEditorTool.
4. Sends the agent a message: "Run mvn compile -f {pom_path} 2>&1 and give me the exact output."
5. Runs the conversation.
6. Reads terminal output from the conversation history.
7. If "BUILD SUCCESS" in output: reads back the (possibly modified) files from workspace, returns success result.
8. If "BUILD FAILURE" in output and attempt < MAX_COMPILE_ATTEMPTS (3): extracts error lines from output (lines containing "[ERROR]" and ".java:"), sends the agent a fix prompt with the errors listed and asks it to fix only the compile errors without changing business logic, runs the conversation again, loops.
9. If all attempts exhausted: returns failure result with the final compile error log.

Return dict: success (bool), files (dict of path→content — compile-verified if success), compile_attempts (int), errors_fixed (list of error strings that were fixed), final_error (string if failed).

## OpenHands Sandbox — forge/openhands/sandbox.py
A thin wrapper that manages the per-file sandbox workspace lifecycle. Methods: create_workspace(file_path) → workspace_path, cleanup_workspace(workspace_path), get_workspace_path(file_path) → deterministic path based on hash of file_path. Workspaces live under /tmp/forge-sandbox/ and are cleaned up after the file is written to ./migrated/.

## Update all three transform agents
In java_upgrade.py, spring_upgrade.py, and struts2_mvc.py: after the LLM generates the output JSON, add a compile verification step. Instantiate OpenHandsCompileVerifier, call verify_and_fix, handle the result:

  If verification success: use the verified files as transform_output. Log errors_fixed to guardrail_findings as "COMPILE_FIXED: {error}". Log compile_attempts to state.
  If verification failure (all attempts exhausted): do NOT proceed to the review agent. Set review_verdict = "MANUAL". Set review_feedback = "Compile verification failed after N attempts: {final_error}". Set status = "MANUAL_REVIEW". Return state. The engineer receives the file with the compile error log as context.
  If enable_compile_verification = False in agents.yaml (dry-run or no Docker): skip verification entirely, use raw LLM output.

## Update agents.yaml
Add: enable_compile_verification (bool, default true), openhands_workspace_base ("/tmp/forge-sandbox"), compile_max_attempts (3), compile_timeout_seconds (120), sandbox_docker_image ("forge-build-env:latest").

## Update ForgeState — forge/state.py
Add to FileStatus: compile_attempts (int, default 0), compile_errors_fixed (list of strings, default empty).

## Update migration-report.md
Add compile verification section: per-file compile_attempts count, total errors auto-fixed across the run, files that failed compile verification (went to MANUAL due to compile failure).

## Tests
test_compile_verifier.py: mock the OpenHands conversation. Test that BUILD SUCCESS returns the corrected files. Test that BUILD FAILURE after MAX_COMPILE_ATTEMPTS returns failure result. Test that --dry-run skips the verifier entirely.

## Acceptance criteria — phase 4 is complete when
1. docker build -t forge-build-env:latest docker/forge-build-env/ succeeds.
2. Running --phase java21 on a file that produces a javax.* import error shows "Compile verify: fixing... attempt 2: BUILD SUCCESS" in the output.
3. The DynamoDB record for that file shows compile_attempts = 2 and compile_errors_fixed containing the import line.
4. Running --dry-run skips compile verification entirely and produces no Docker activity.
5. test_compile_verifier.py passes with mocked OpenHands conversation.
