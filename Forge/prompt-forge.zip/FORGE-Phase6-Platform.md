# FORGE — Phase 6: Platform Hardening
# Build on top of Phases 0 through 5
# FORGE becomes a platform, not just a migration tool

## Prerequisite
Phases 0 through 5 are complete. FORGE migrates Struts 2 applications end-to-end: Java upgrade, Spring upgrade, Struts elimination, containerization, and test generation. It produces compile-verified, deployment-ready output. This phase makes FORGE a reusable platform: SQS for production manual review handling, Bedrock Knowledge Base for RAG-grounded transforms, multi-application support, pluggable agent loading from config, and the full observability stack with CloudWatch dashboards.

## Goal
After this phase, FORGE is a platform that a team can run continuously — not a one-time script. Any framework migration can be added by dropping in a new agent class and updating agents.yaml. No pipeline changes required.

## What "done" looks like for this phase

  python migrate.py ./myapp ./ordersapp ./paymentsapp --phase struts

Processes three applications in one run. Each app has its own DynamoDB partition. Progress for all three visible in CloudWatch dashboard simultaneously.

The manual-review-queue.json is replaced by an SQS queue. Engineers open the review portal (review_portal.py) which polls SQS and presents each MANUAL file with full context: original, best attempt, review feedback, specific flags. Engineer approves or rejects. Approved files go to ./migrated/. Rejected files go back to PENDING for a new transform attempt.

Adding a new agent for a future framework (e.g. JSF → Thymeleaf): create forge/agents/jsf_thymeleaf.py following the BaseAgent pattern, add jsf_to_thymeleaf to agents.yaml phase_agents.jsf entry. No other changes.

## New files to add

forge/
  queue/
    sqs_queue.py          ← new (replaces manual-review-queue.json)
  rag/
    __init__.py           ← new
    knowledge_base.py     ← new (Bedrock Knowledge Base client)
  observability/
    __init__.py           ← new
    cloudwatch.py         ← new (custom metrics publisher)
    dashboard.py          ← new (CloudWatch dashboard definition)
  plugin/
    __init__.py           ← new
    agent_loader.py       ← new (load agents from agents.yaml config)
review_portal.py          ← new (CLI for engineers to review MANUAL files)
infrastructure/
  create_sqs.py           ← new
  create_knowledge_base.py ← new
  create_cloudwatch_dashboard.py ← new
tests/
  test_sqs_queue.py       ← new
  test_rag.py             ← new
  test_agent_loader.py    ← new

## SQS Manual Review Queue — forge/queue/sqs_queue.py
Replace the manual-review-queue.json file with an AWS SQS queue. Queue name from agents.yaml. Dead-letter queue for messages that fail processing 3 times. Visibility timeout 30 minutes (gives engineer time to review without another engineer picking it up simultaneously).

Methods: push_manual_file(file_status, context_bundle) — sends a message with full context as JSON body. poll_manual_files(max_count=10) — receives up to 10 messages. acknowledge(receipt_handle) — deletes message after engineer action. reject(receipt_handle) — puts file back to PENDING in DynamoDB, deletes SQS message.

Update forge/queue/manual_queue.py: check agents.yaml use_sqs flag. If True: use SqsQueue. If False: write to manual-review-queue.json (keeps backward compatibility for developers without SQS setup).

## Review Portal — review_portal.py
A CLI tool for engineers to process MANUAL files. Run: python review_portal.py

Shows one file at a time:
- File path and risk score
- Original source (diff view if possible)
- Best transformation attempt
- Review feedback from Nova Pro
- Specific flags (OGNL patterns, interceptor issues)
- Compile errors if compile verification failed

Engineer choices: (a) Approve — write the best attempt to ./migrated/ as-is. (r) Reject with note — engineer types a note, file goes back to PENDING with the note injected as review_feedback for the next transform attempt. (s) Skip — return message to SQS for later. (q) Quit.

## Bedrock Knowledge Base RAG — forge/rag/knowledge_base.py
A client for the Bedrock Knowledge Base. Methods: retrieve(query, top_k=5) → list of relevant document chunks.

Integrate into transform agents: before the main system prompt, call retrieve() with a query like "Spring MVC migration patterns for {file_type}" or "enterprise naming conventions". Append the retrieved chunks to the system prompt as additional context. This grounds the transform agents in your specific coding standards and architecture decisions.

Documents to upload to the Knowledge Base (create as placeholder files with instructions):
  coding_standards.md — your enterprise Java naming conventions, package structure rules
  spring_migration_patterns.md — approved Spring 6 configuration patterns
  struts2_to_mvc_rules.md — known edge cases from this migration
  arch_decisions.md — ADRs relevant to the target architecture
  liberty_config_standards.md — approved Liberty feature sets per app type

The Knowledge Base ID comes from agents.yaml. If knowledge_base_id is not set: skip RAG retrieval silently. This makes RAG opt-in — teams can run FORGE without it and add it when they have curated content.

## CloudWatch Observability — forge/observability/cloudwatch.py
Publish custom metrics to CloudWatch under the FORGE/Migration namespace. Metrics to emit after each file:
  files_processed (count)
  files_passed (count)
  files_retried (count)
  files_manual (count)
  files_blocked (count)
  review_score (value, dimension: phase)
  retry_count (value)
  bedrock_calls (count)
  compile_attempts (value)
  estimated_cost_usd (value)

Publish after every file completes. Batch metrics where possible (CloudWatch allows up to 20 per call).

## CloudWatch Dashboard — forge/observability/dashboard.py
Generate a CloudWatch dashboard definition (JSON) with widgets:
  Migration progress: files DONE / files PENDING / files MANUAL (gauge)
  Review score distribution: histogram of scores across the run
  Retry rate: retries per hour time series
  Estimated cost: cumulative cost time series
  Agent performance: Bedrock calls per agent type
  Error rate: BLOCKED and MANUAL rate time series

Create the dashboard in infrastructure/create_cloudwatch_dashboard.py.

## Pluggable Agent Loader — forge/plugin/agent_loader.py
Load agent classes dynamically from agents.yaml phase_agents configuration. Instead of importing agents directly in graph.py, read the phase_agents section from agents.yaml. For each phase: dynamically import the specified module and class, instantiate with config, register as a LangGraph node.

This means adding a new agent requires: create forge/agents/new_agent.py, add it to agents.yaml phase_agents.new_phase entry. The graph automatically picks it up. No changes to graph.py, no changes to the CLI.

## Multi-application support — update migrate.py
Accept multiple source_dir arguments: python migrate.py ./app1 ./app2 ./app3 --phase struts

For each app: create a separate namespace in DynamoDB (keyed by app name). Run the full pipeline for each app. Progress printed with app name prefix: [app1: 45/247] UserAction.java → DONE.

Each app's manifest, output, and report are separate. ./migrated/app1/, ./migrated/app2/, ./migrated/app3/.

## Update agents.yaml for platform features
Add: use_sqs (bool, default false), sqs_queue_url, knowledge_base_id (optional — skip if absent), cloudwatch_namespace ("FORGE/Migration"), cloudwatch_dashboard_name ("forge-migration"), enable_rag (bool, default false).

Extend phase_agents to show the pluggable pattern:
  phase_agents:
    java21: [java_upgrade]
    spring6: [spring_upgrade]
    struts: [struts2_mvc]
    containerize: [containerize]
    testgen: [test_gen]
    # Future frameworks — add here without code changes:
    # jsf: [jsf_thymeleaf]
    # ejb: [ejb_spring]
    # hibernate5: [hibernate_upgrade]

## Update requirements.txt
Add: watchtower (CloudWatch logging handler).

## Tests
test_sqs_queue.py: mock SQS client. Test that push_manual_file sends a message with correct body. Test that poll returns correctly structured file status. Test that acknowledge deletes the message.
test_rag.py: mock Bedrock Knowledge Base client. Test that retrieve returns chunks. Test that if knowledge_base_id is absent, retrieve returns empty list without error.
test_agent_loader.py: given a agents.yaml with java_upgrade in phase_agents.java21, assert the loader returns an instance of JavaUpgradeAgent.

## Acceptance criteria — phase 6 is complete when
1. python migrate.py ./app1 ./app2 --phase struts processes both apps and writes to ./migrated/app1/ and ./migrated/app2/ separately.
2. MANUAL files appear in SQS (when use_sqs=true) instead of manual-review-queue.json.
3. python review_portal.py shows MANUAL files with approve/reject options.
4. CloudWatch dashboard shows real-time migration progress metrics.
5. Adding a new agent class and one agents.yaml entry makes it available in the pipeline without any other code change — verified by test_agent_loader.py.
6. All three new tests pass.

---

## FULL PHASE SUMMARY

| Phase | What it builds | Proves |
|---|---|---|
| 0 MVP | Java upgrade agent, full pipeline, DynamoDB, LangSmith | End-to-end pipeline works |
| 1 Discovery | File classifier, dependency graph, risk scorer, manifest | Processing order and pre-triage work |
| 2 Spring | Spring upgrade agent, LiteLLM abstraction | Multi-agent, provider-swappable |
| 3 Struts | Struts elimination, context builder, struts.xml parser | Cross-file context, human gates |
| 4 OpenHands | Compile verification, Docker sandbox, auto-fix | Developer experience, zero compile errors |
| 5 Container+Test | Containerize agent, Test Gen agent | Production-ready output |
| 6 Platform | SQS, RAG, CloudWatch, pluggable agents, multi-app | Extensible platform |

Run each phase with Claude Code independently. Each builds directly on the previous. Each is shippable and testable on its own.
